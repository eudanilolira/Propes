function showError(){
    alert("Não foi possível se cadastrar, verifique os erros e tente novamente");
};
